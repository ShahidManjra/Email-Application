package EmailApp;

import java.util.Scanner;

public class Email {

    private String Firstname;
    private String Lastname;
    private String Password;
    private String Department;
    private String Email;
    private int MailboxCapacity = 500;
    private int defaultpasswordlength = 10;
    private String alternativeEmail;
    private String CompanyDomain = "ITSupport.com";

    //Constructor to receive the first and last name
    public Email() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter email account first name: ");
        this.Firstname = in.nextLine();

        System.out.print("Enter email account last name: ");
        this.Lastname = in.nextLine();

        // call method to ask for department
        this.Department = setDepartment();


        // call method to call random password
        this.Password = SetPassword(defaultpasswordlength);

        // combine elements to generate email
        Email = Firstname.toLowerCase() + "" + Lastname.toLowerCase() + "@" + CompanyDomain;


    }

    //Ask for the department
    private String setDepartment() {
        System.out.println("Enter the account department: \n1 for Application Support \n2 for Development\n3 for Infrastructure\n0 for not applicable");
        Scanner in = new Scanner(System.in);
        int Dept = in.nextInt();
        if (Dept == 1) {
            return "Application Support";
        } else if (Dept == 2) {
            return "Development";
        } else if (Dept == 3) {
            return "Infrastructure";
        } else {
            return "N/A";
        }

    }

    //Generate random password
    private String SetPassword(int length) {
        String passwordset = "ABCDEFGHIJKLMONPQRSTUVWXYZ0123456789!@#$%";
        char[] password = new char[length];
        for (int i = 0; i < length; i++) {
            int rand = (int) (Math.random() * passwordset.length());
            password[i] = passwordset.charAt(rand);

        }
        return new String(password);
    }

    //set mailbox capacity
    public void setMailboxCapacity(int capacity) {
        this.MailboxCapacity = capacity;

    }

    //Set alternate email
    public void setAlternativeEmail(String altemail) {
        this.alternativeEmail = altemail;
    }

    //Change password
    public void changepassword(String password) {
        this.Password = password;
    }

    public int getMailboxCapacity() {
        return MailboxCapacity;
    }

    public String getAlternativeEmail() {
        return alternativeEmail;
    }

    public String getPassword() {
        return Password;

    }

    public String showinfo() {
        return "\nEmail Account Information" + "\n__________________________" +
                "\nDisplay name: "  + Firstname + " " + Lastname +
                "\nAccount Password: " + Password +
                "\nCompany Email: " + Email +
                "\nCompany Department: " + Department +
                "\nMailbox Capacity: " + MailboxCapacity  + "mb";
    }
}
