package EmailApp;

public class EmailMainMethod {

    public static void main(String[] args) {
        Email n1 = new Email();

        System.out.println(n1.showinfo());

    }
}
